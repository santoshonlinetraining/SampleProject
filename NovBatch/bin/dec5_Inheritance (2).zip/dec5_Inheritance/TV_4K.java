package dec5_Inheritance;

public class TV_4K extends BlackAndWhiteTV{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
