package dec5_Inheritance;

interface ClassA {

}
