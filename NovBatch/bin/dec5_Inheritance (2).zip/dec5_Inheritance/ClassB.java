package dec5_Inheritance;

public interface ClassB {

}
