package dec5_Inheritance;

public class ClassC implements ClassA, ClassB {

}
