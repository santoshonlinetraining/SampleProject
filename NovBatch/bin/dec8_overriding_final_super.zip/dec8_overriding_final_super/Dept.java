package dec8_overriding_final_super;

public class Dept extends Emp {

	String companyName = "XYZ";
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
