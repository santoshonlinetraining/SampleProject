package dec9_access_modifiers_new;

import dec9_access_modifiers.Emp;

public class AccountsDept extends Emp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Emp obj = new Emp();
		
		
		AccountsDept obj2 = new AccountsDept();
		obj2.bonus();
		
		
	}

}
