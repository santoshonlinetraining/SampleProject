package dec9_access_modifiers;

 public class Emp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	void salary() {
		System.out.println("salary is 10000");
	}
	
	
	protected void bonus() {
		System.out.println("em bonus is 1000" );
	}
	
	

}
