package dec9_access_modifiers;

public class Dept {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Emp obj = new Emp();
		
		obj.salary();
		obj.bonus();
		
		Student objStudent = new Student();
		
		
		
	}

}
