package dec11;

public interface Teachers {

	void salary();
	void subject();
	
	
}
