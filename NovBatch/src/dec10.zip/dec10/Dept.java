package dec10;

public class Dept {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Emp obj = new Emp();
		//ystem.out.println(obj.salary);
		
		System.out.println(obj.getSalary());
		
		
		
	}

}
