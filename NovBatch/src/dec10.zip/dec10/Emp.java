package dec10;

public class Emp {

	private int salary = 10000;
	
	
	int getSalary() {
		salary = salary - 200;
		return salary;
	}
	
	

}
